//
//  Ghost.hpp
//  testSFML
//
//  Created by YuYao Tu on 9/19/23.
//

#ifndef Ghost_hpp
#define Ghost_hpp
#include <iostream>
#include <array>
#include "Global.hpp"
#include "Collision.hpp"
#include <SFML/Graphics.hpp>
#include <cmath>
#include <stdio.h>
#include "pacman.hpp"
#include "pacman.cpp"

class Ghost{
    int direction;
//    Position position;
    Position target;
    int ghostSpeed;
private:
    float x, y;  // Ghost 的位置
    float speed=2.0f;// 移动速度
    sf::Texture texture; // 纹理用于存储图像
    sf::Sprite sprite; // 精灵用于显示图像
public:
    Position position;
    Ghost();
    Position getPosition();
    void setPosition(int x, int y);
    void draw(sf::RenderWindow& myWindow);
    void move(float deltaTime);
    void update(std::array<std::array<Cell, 20>, 21>& outputMap, Ghost& ghost, Pacman& pacman);
    float getDistance (int direction, Pacman& pacman);
    void initialPos(std::vector<std::string> map_script, Ghost& ghost);
    
    float getX() const { return x; }
    float getY() const { return y; }
};
#endif /* Ghost_hpp */
