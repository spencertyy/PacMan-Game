#include <SFML/Graphics.hpp>
#include <array>
#include <chrono>
#include <ctime>
#include "Global.hpp"
#include "pacman.hpp"
#include "ProcessScript.hpp"
#include "DrawMap.hpp"
#include "Ghost.hpp"
#include "Collision.hpp"
#include <iostream>
#include <chrono>
#include <thread>


int main()
{
    
    // create the window
    sf::RenderWindow window(sf::VideoMode(600 , 630), "PacMan");
    sf::Vector2f pacmanPosition; // Pacman 的位置
    sf::Vector2f ghostPosition;  // Ghost 的位置
    bool gameOver = false;

    // run the program as long as the window is open
    std::vector<std::string> map_script={
    
    "####################",
    "#..................#",
    "#.#...#.####.###...#",
    "#.##.##.#....#  #..#",
    "#.#####.#....#   #.#",
    "#.#.#.#.#....#   #.#",
    "#.#.#.#.####.#   #.#",
    "#.#.#.#....#.#   #.#",
    "#.#...#..G.#.#  #..#",
    "#.#...#.####.###...#",
    "....................",
    "#.####.####.#.####.#",
    "#.#....#  #.#.#  #.#",
    "#.#....#  #.#.#  #.#",
    "#.####.#  #.#.#  #.#",
    "#.#  #.#  #.#.#  #.#",
    "#.#  #.#  #.#.#  #.#",
    "#.#  #.#  #.#.#  #.#",
    "#.####.####.#.####.#",
    "#........P.........#",
    "####################"};
    
    Pacman pacman;
    Ghost ghost;
    pacman.initialPos(map_script, pacman);
    ghost.initialPos(map_script, ghost);
    std::array<std::array<Cell, 20>, 21> map;
    map = ProcessScript(map_script);
    
    

//    std::vector<sf::Vector2i> dots = {"."};
//    dot.initialPos(map_script, dot);
//    std::array<std::array<Cell,  20>,21>map2;
//    map = ProcessScript(map_script);
//    sf::RectangleShape rectangle;
//    rectangle.setSize(sf::Vector2f(cellSize, cellSize));
//    rectangle.setFillColor(sf::Color::Blue);
//
//    sf::CircleShape dot(4);
//    dot.setFillColor(sf::Color::Yellow);
    
//    dot.setPosition(centerX - 5, centerY - 5);
//    sf::RectangleShape rectangleShade;
//    rectangleShade.setSize(sf::Vector2f(cellSize, cellSize));
//    rectangleShade.setFillColor(sf::Color(39,730,710));
//    Pacman pacman(100, 100, 5.0f);
//    pacman.setPosition(0, 0);

//     创建 Ghost
//    Ghost ghost(100.0f, 100.0f, 100.0f); // 初始位置 (100, 100)，速度 100
//    ghost.setPosition(0, 0);

    window.setFramerateLimit(60);
   while (window.isOpen())
   {
       sf::Event event;
       while (window.pollEvent(event))
       {
           if (event.type == sf::Event::Closed)
               window.close();
       }
       
       ghost.update(map, ghost);
       pacman.update(map, pacman);
       int pelletEaten = pacman.eatPellet(map, pacman);
       


//       if (sf::Keyboard::isKeyPressed(sf::Keyboard::Up)) {
//           pacman.moveUp();
//       pacman.draw(window);
//       }
//
//       if (sf::Keyboard::isKeyPressed(sf::Keyboard::Down))
//           pacman.moveDown();
//       if (sf::Keyboard::isKeyPressed(sf::Keyboard::Left))
//           pacman.moveLeft();
//       if (sf::Keyboard::isKeyPressed(sf::Keyboard::Right))
//           pacman.moveRight(1, 1.0f);
//

       // Clear the window
       window.clear();
       
       drawMap(map, window);
    
      
       
       pacman.setPosition(pacman.getPosition().x, pacman.getPosition().y);
       std::cout << "the current y position of pacman : " << pacman.getPosition().x << "and "<<ghost.getX()<< "\n";
       pacman.draw(window);
       
       ghost.setPosition(ghost.position.x, ghost.position.y);
       std::cout << "the current y position of ghost : " << ghost.position.x << "\n";
       ghost.draw(window);
       
       gameOver = (pacman.getPosition().x  ==  ghost.position.x) && (pacman.getPosition().y  ==  ghost.position.y);
       
       if (gameOver) {
           sf::Texture gameOverTexture;
           if (!gameOverTexture.loadFromFile("/Users/yuyaotu/Desktop/myGithubRepo/FinalProject/src/gameover.png")) {
               // 处理加载失败的情况
           }
           sf::Sprite gameOverSprite;
           gameOverSprite.setTexture(gameOverTexture);
           window.draw(gameOverSprite);
           window.display();
           std::this_thread::sleep_for(std::chrono::seconds(5));
           exit(1);
        }

       window.display();
   }
   return 0;
}
           





